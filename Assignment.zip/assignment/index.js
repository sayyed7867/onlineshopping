function myFunction1() {
  document.getElementById("myDropdown").classList.toggle("show");
}


function myFunction() {
    
    alert("Success");
  }